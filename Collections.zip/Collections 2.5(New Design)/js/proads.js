const firebaseConfig = {
  apiKey: "AIzaSyBc18kFu_5W7n2-q5pc5HgxKGsMU-1kLd0",
  authDomain: "collection712.firebaseapp.com",
  databaseURL: "https://collection712-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "collection712"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db   = firebase.database();

const slider = document.getElementById("slider");
const cards  = document.querySelectorAll(".card");
const dotsContainer = document.getElementById("dots");

let current = 0;
let userPlan = "free";

/* DOT */
cards.forEach((_,i)=>{
  const dot = document.createElement("span");
  if(i===0) dot.classList.add("active");
  dotsContainer.appendChild(dot);
});
const dots = dotsContainer.querySelectorAll("span");

function updateSlider(){
  const wrapper = slider.parentElement;
  const cardWidth = cards[0].offsetWidth + 20; // 20 là gap
  const wrapperWidth = wrapper.clientWidth;   // không tính padding
  const offset = (wrapperWidth - cards[0].offsetWidth) / 2;

  slider.style.transform = `translateX(${-current * cardWidth + offset}px)`;

  cards.forEach(c=>c.classList.remove("active"));
  cards[current].classList.add("active");

  dots.forEach(d=>d.classList.remove("active"));
  dots[current].classList.add("active");
}

window.addEventListener("load", updateSlider);
window.addEventListener("resize", updateSlider);

/* SWIPE */
let startX = 0;

slider.addEventListener("touchstart",e=>{
  startX = e.touches[0].clientX;
});

slider.addEventListener("touchend",e=>{
  let diff = startX - e.changedTouches[0].clientX;

  if(diff > 50 && current < cards.length-1) current++;
  else if(diff < -50 && current > 0) current--;

  updateSlider();
});

/* CHECK PLAN */
auth.onAuthStateChanged(user=>{
  if(!user) return;

  db.ref("users/"+user.uid).once("value").then(snap=>{
    userPlan = snap.val()?.premiumPlan || "free";

    cards.forEach(card=>{
      if(card.dataset.plan === userPlan){
        card.querySelector(".price").innerText = "Đang sử dụng";
      }
    });
  });
});