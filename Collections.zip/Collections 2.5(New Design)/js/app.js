// ================= FIREBASE INIT =================
const firebaseConfig = {
  apiKey: "AIzaSyBc18kFu_5W7n2-q5pc5HgxKGsMU-1kLd0",
  authDomain: "collection712.firebaseapp.com",
  databaseURL: "https://collection712-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "collection712"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db   = firebase.database();

// ================= BIẾN TOÀN CỤC =================
const searchInput = document.getElementById("searchInput");
const loginNotice = document.getElementById("loginNotice");

let premiumPlan = "free";
let totalImagesCount = 0;
let allCollectionCards = [];

const PLAN_LIMITS = { free: 1000, basic: 10000, advanced: 50000, pro: 100000, unlimited: Infinity };

let deleteId = null;

// ================= BIẾN CHỐNG LAG & CUỘN VÔ HẠN =================
let globalAllMedia = [];
let currentRenderIndex = 0;
const RENDER_BATCH_SIZE = 30; // Nạp 30 tấm mỗi lần lướt
let scrollObserver = null;
let globalCollectionsListener = null;
let isRendering = false; // Khóa phanh chống kẹt mạng

// ================= ELEMENTS =================
const avatar      = document.getElementById("avatar");
const popup       = document.getElementById("accountPopup");
const popupAvatar = document.getElementById("popupAvatar");
const popupEmail  = document.getElementById("popupEmail");

// ================= HÀM ÉP ẢNH THUMBNAIL (BÓP SIÊU NHẸ MÀ VẪN NÉT) =================
function getOptimizedThumbnail(url) {
  if (!url) return "";
  try {
    if (url.includes("/image/upload/")) {
      return url.replace("/image/upload/", "/image/upload/c_fill,w_300,h_300,q_auto,f_auto/");
    }
  } catch(e) {}
  return url;
}

if (avatar) {
  avatar.onclick = () => {
    if (!auth.currentUser) location.href = "login.html";
    else openAccount();
  };
}

// ================= LUỒNG TẢI DỮ LIỆU CHÍNH =================
auth.onAuthStateChanged(user => {
  const allGrid = document.getElementById("allImagesGrid");

  if (!user) {
    if(loginNotice) loginNotice.style.display = "flex";
    if(allGrid) allGrid.style.display = "none";
    if(avatar) avatar.innerHTML = `<i class="fa-solid fa-user"></i>`;
    return;
  }

  if(loginNotice) loginNotice.style.display = "none";
  if(allGrid) allGrid.style.display = "grid";

  db.ref("users/" + user.uid).once("value").then(snap => {
    const data = snap.val() || {};
    premiumPlan = data.premiumPlan || "free";
    if(avatar) avatar.innerHTML = data.avatar ? `<img src="${data.avatar}" style="width:100%;height:100%;border-radius:50%;object-fit:cover">` : `<i class="fa-solid fa-user"></i>`;
    if(popupAvatar && data.avatar) {
      popupAvatar.src = data.avatar;
      popupAvatar.style.display = "block";
    }
  });

  if (globalCollectionsListener) {
    db.ref("collections").orderByChild("uid").equalTo(user.uid).off("value", globalCollectionsListener);
  }

  globalCollectionsListener = db.ref("collections")
    .orderByChild("uid")
    .equalTo(user.uid)
    .on("value", snap => {
      const collections = [];
      const allMedia = [];
      let count = 0;

      snap.forEach(child => {
        try {
          const col = child.val();
          col.key = child.key;
          collections.push(col);

          const imgs = col.imgs ? Object.values(col.imgs) : [];
          const vids = col.videos ? Object.values(col.videos) : [];

          count += imgs.length;
          vids.forEach(v => count += (v.cost || 20));

          if (col.imgs) {
            Object.entries(col.imgs).forEach(([imgKey, url]) => {
              allMedia.push({ type: "image", collectionId: child.key, key: imgKey, url });
            });
          }
          if (col.videos) {
            Object.entries(col.videos).forEach(([vidKey, video]) => {
              allMedia.push({ type: "video", collectionId: child.key, key: vidKey, url: video.url });
            });
          }
        } catch(e) {
          console.error("Lỗi đọc 1 bộ sưu tập:", e);
        }
      });

      totalImagesCount = count;
      updateStorageUI();
      renderCollectionsGrid(collections);

      allMedia.reverse(); 
      globalAllMedia = allMedia;

      try {
        sessionStorage.setItem("allImages", JSON.stringify(allMedia));
      } catch (e) {
        console.warn("Quá nhiều ảnh, không thể lưu đệm!");
      }

      const grid = document.getElementById("allImagesGrid");
      if (grid) {
        grid.innerHTML = "";
        currentRenderIndex = 0;
        isRendering = false; // Reset khóa
        if (scrollObserver) scrollObserver.disconnect();

        if (allMedia.length === 0) {
          grid.innerHTML = `<div class="empty-center"><i class="fa-regular fa-image"></i><p>Chưa có dữ liệu nào 🥹</p></div>`;
        } else {
          setupScrollObserver(); // Cài bộ theo dõi trước
          renderMediaBatch();    // Nạp đợt đầu tiên
        }
      }
    });
});

// ================= RENDER BỘ SƯU TẬP =================
function renderCollectionsGrid(collections) {
  const grid = document.getElementById("collectionsGrid");
  if (!grid) return;
  
  grid.innerHTML = "";
  allCollectionCards = [];

  collections.forEach(col => {
    const imgs = col.imgs ? Object.values(col.imgs) : [];
    const vids = col.videos ? Object.values(col.videos) : [];
    const totalCount = imgs.length + vids.length;
    
    let cover = "https://placehold.co/300x300/333/FFF?text=Trống";
    if (vids.length > 0) {
      cover = vids[vids.length - 1].url.replace("/video/upload/", "/video/upload/c_fill,w_300,h_300,q_auto,f_auto/").replace(".mp4", ".jpg");
    }
    if (imgs.length > 0) {
      cover = getOptimizedThumbnail(imgs[imgs.length - 1]);
    }

    const card = document.createElement("div");
    card.className = "collection-card";
    card.oncontextmenu = e => e.preventDefault();

    let pressTimer;
    card.addEventListener("touchstart", () => {
      pressTimer = setTimeout(() => showCollectionOptions(col.key), 500);
    });
    card.addEventListener("touchend", () => clearTimeout(pressTimer));
    card.addEventListener("click", () => location.href = `add.html?id=${col.key}`);

    card.innerHTML = `
      <img src="${cover}" loading="lazy" draggable="false" style="background:#222;">
      <div class="collection-info">
        <div class="collection-name">${col.name || "Không tên"}</div>
        <div class="collection-count">${totalCount}</div>
      </div>
    `;

    card.dataset.name = (col.name || "").toLowerCase();
    allCollectionCards.push(card);
    grid.appendChild(card);
  });
}

// ================= RENDER THƯ VIỆN & CỤC ĐANG TẢI =================
function renderMediaBatch() {
  if (isRendering || currentRenderIndex >= globalAllMedia.length) return;
  isRendering = true; // Bật khóa phanh

  const grid = document.getElementById("allImagesGrid");
  if (!grid) return;

  // Xóa cục loading cũ
  const oldSentinel = document.getElementById("scroll-sentinel");
  if (oldSentinel) grid.removeChild(oldSentinel);

  // Tạo độ trễ nhỏ để UI không bị đơ khi xử lý hàng loạt
  setTimeout(() => {
    const endIndex = Math.min(currentRenderIndex + RENDER_BATCH_SIZE, globalAllMedia.length);
    const fragment = document.createDocumentFragment(); 

    for (let i = currentRenderIndex; i < endIndex; i++) {
      const item = globalAllMedia[i];
      
      const wrapper = document.createElement("div");
      wrapper.className = "media-item";

      const element = document.createElement("img");
      element.loading = "lazy";
      element.style.width = "100%";
      element.style.aspectRatio = "1 / 1";
      element.style.objectFit = "cover";
      element.style.borderRadius = "14px";
      element.draggable = false;
      element.oncontextmenu = e => e.preventDefault();

      // Thêm màu nền dự phòng khi ảnh chưa tải xong
      element.style.backgroundColor = "#2a2a2a";

      if (item.type === "image") {
        element.src = getOptimizedThumbnail(item.url); 
      } else {
        const thumbUrl = item.url.replace("/video/upload/", "/video/upload/c_fill,w_300,h_300,q_auto,f_auto/").replace(".mp4", ".jpg");
        element.src = thumbUrl;
        const badge = document.createElement("div");
        badge.className = "video-badge";
        badge.innerHTML = `<i class="fa-solid fa-play"></i><span>Video</span>`;
        wrapper.appendChild(badge);
      }

      element.addEventListener("click", () => {
        sessionStorage.setItem("startIndex", i);
        location.href = "view.html"; 
      });

      wrapper.insertBefore(element, wrapper.firstChild);
      fragment.appendChild(wrapper);
    }

    grid.appendChild(fragment);
    currentRenderIndex = endIndex;

    // Nếu vẫn còn ảnh thì tạo cục Loading mới
    if (currentRenderIndex < globalAllMedia.length) {
      const sentinel = document.createElement("div");
      sentinel.id = "scroll-sentinel";
      sentinel.style.gridColumn = "1 / -1"; 
      sentinel.style.padding = "30px 0";
      sentinel.style.textAlign = "center";
      sentinel.style.color = "var(--gray)";
      sentinel.style.fontSize = "15px";
      sentinel.style.fontWeight = "600";
      sentinel.innerHTML = `<i class="fa-solid fa-spinner fa-spin" style="margin-right: 8px;"></i>Đang tải thêm...`;
      
      grid.appendChild(sentinel);
      
      // Delay một xíu mới cho phép bắt sự kiện cuộn tiếp, ngăn vòng lặp vô hạn
      setTimeout(() => {
        if (scrollObserver) scrollObserver.observe(sentinel);
        isRendering = false; // Mở khóa
      }, 300);
    } else {
      isRendering = false; // Đã hết ảnh, mở khóa
    }
  }, 50); // Delay 50ms cho browser kịp thở
}

// ================= CÀI ĐẶT THEO DÕI CUỘN TRANG =================
function setupScrollObserver() {
  if (scrollObserver) scrollObserver.disconnect();

  scrollObserver = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting && !isRendering) {
      scrollObserver.unobserve(entries[0].target); // Ngưng theo dõi cục hiện tại ngay lập tức
      renderMediaBatch(); // Nạp mẻ mới
    }
  }, { rootMargin: "100px" }); // Rút ngắn vùng nhận diện lại để không bị kích hoạt quá sớm
}

// ================= CÁC TÍNH NĂNG KHÁC CÒN LẠI =================
function openAccount() {
  if (!popup) return;
  popup.classList.add("show");
  if (popupEmail) popupEmail.innerText = auth.currentUser.email;
  updateStorageUI(); 
}
function closeAccount() { popup?.classList.remove("show"); }
function logout() { auth.signOut().then(() => location.reload()); }

function showCollectionOptions(id) {
  deleteId = id;
  document.getElementById("optionsPopup")?.classList.add("show");
}
function closeOptions() { document.getElementById("optionsPopup")?.classList.remove("show"); }
function confirmDelete() {
  if (!deleteId) return;
  if (confirm("Bạn chắc chắn muốn xoá bộ sưu tập này không? 🥹")) {
    db.ref("collections/" + deleteId).remove();
  }
  closeOptions();
}

if (searchInput) {
  searchInput.addEventListener("input", () => {
    const keyword = searchInput.value.toLowerCase().trim();
    allCollectionCards.forEach(card => {
      card.style.display = card.dataset.name.includes(keyword) ? "" : "none";
    });
  });
}

const sheet = document.getElementById("bottomSheet");
const sheetBody = document.getElementById("sheetBody");
function openSheet(type) {
  if (!sheet) return;
  if (type === "data") {
    sheetBody.innerHTML = `
      <div class="sheet-icon"><i class="fa-solid fa-shield-halved"></i></div>
      <div class="sheet-title">Quyền riêng tư dữ liệu</div>
      <div class="sheet-desc">🔒 Dữ liệu không bị lộ ra ngoài kể cả chúng tôi cũng không có quyền xem.</div>
      <div class="sheet-desc">📛 Dữ liệu không bị dùng để bán hoặc quảng cáo theo cá nhân hoá.</div>
      <div class="sheet-desc">🛡️ Cập nhật bảo mật thường xuyên.</div>
      <div class="sheet-desc" style="margin-top:15px;font-weight:600;">Cảm ơn đã sử dụng ứng dụng!</div>
    `;
  }
  if (type === "about") {
    sheetBody.innerHTML = `
      <div class="app-icon"><img src="icons/icon-512.png"></div>
      <div class="sheet-title">Bộ sưu tập</div>
      <div style="opacity:.6;margin-bottom:15px;">Phiên bản 1.0</div>
      <div class="about-item" onclick="window.location.href='mailto:thanhkawaii07122008@gmail.com'">
        <i class="fa-solid fa-envelope"></i> Liên hệ <small>Gửi mail tới chúng tôi để được trợ giúp.</small>
      </div>
      <div class="about-item" style="cursor:default;">
        <i class="fa-solid fa-code"></i> Bởi ThànhKawaii <small>Trang web được xây dựng bởi ThànhKawaii</small>
      </div>
    `;
  }
  sheet.classList.add("show");
}
function closeSheet() { sheet.classList.remove("show"); }

const gridBtn = document.getElementById("gridBtn");
const gridPopup = document.getElementById("gridPopup");
const grid = document.getElementById("allImagesGrid");
if (gridBtn) gridBtn.onclick = () => gridPopup.classList.toggle("show");

function setGrid(cols){
  grid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  localStorage.setItem("gridCols", cols);
  gridPopup.classList.remove("show");
}

window.addEventListener("DOMContentLoaded", () => {
  const saved = localStorage.getItem("gridCols") || 3;
  if(grid) grid.style.gridTemplateColumns = `repeat(${saved}, 1fr)`;
  switchTab('library', 0); 
});

function updateStorageUI(){
  const text = document.getElementById("storageText");
  const bar  = document.getElementById("storageProgress");
  if(!text || !bar) return;
  const max = PLAN_LIMITS[premiumPlan] || 1000;
  if(max === Infinity){
    text.innerHTML = `${totalImagesCount} / ♾️ Không giới hạn`;
    bar.style.width = "100%"; bar.style.background = "linear-gradient(90deg,#f59e0b,#fbbf24)";
    return;
  }
  const percent = Math.min((totalImagesCount / max) * 100, 100);
  text.innerHTML = `${totalImagesCount} / ${max}`;
  bar.style.width = percent + "%";
  bar.style.background = percent > 90 ? "linear-gradient(90deg,#ef4444,#f87171)" : "linear-gradient(90deg,#3b82f6,#60a5fa)";
}

document.addEventListener("DOMContentLoaded", () => {
  const storageBox = document.getElementById("storageBox");
  if(storageBox){
    storageBox.style.cursor = "pointer";
    storageBox.addEventListener("click", () => location.href = "proads.html");
  }
});

function formatTime(seconds){
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}`;
}

function switchTab(tabName, index) {
  document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
  document.querySelectorAll('.ios-tabbar .tab').forEach(el => el.classList.remove('active'));

  document.getElementById('view-' + tabName).style.display = 'block';
  document.getElementById('tab-' + tabName).classList.add('active');

  const indicator = document.getElementById('tabIndicator');
  if(indicator) indicator.style.transform = `translateX(${index * 90}px)`;

  const title = document.getElementById('toolbarTitle');
  const gridBtn = document.getElementById('gridBtn');
  const floatingActions = document.getElementById('floatingActions');
  const searchContainer = document.getElementById('searchContainer');

  if (tabName === 'library') {
    if(title) title.innerText = 'Thư viện';
    if(gridBtn) gridBtn.style.display = 'flex'; 
    if(floatingActions) floatingActions.style.display = 'none'; 
    if(searchContainer) {
      searchContainer.classList.remove('show');
      const input = document.getElementById('searchInput');
      if(input) input.value = '';
    }
  } else if (tabName === 'collections') {
    if(title) title.innerText = 'Bộ sưu tập';
    if(gridBtn) gridBtn.style.display = 'none'; 
    if(floatingActions) floatingActions.style.display = 'flex'; 
  }
}

function toggleSearch() {
  const container = document.getElementById('searchContainer');
  const input = document.getElementById('searchInput');
  if (container.classList.contains('show')) {
    container.classList.remove('show');
    input.value = ''; 
    input.dispatchEvent(new Event('input')); 
  } else {
    container.classList.add('show');
    setTimeout(() => input.focus(), 100); 
  }
}
