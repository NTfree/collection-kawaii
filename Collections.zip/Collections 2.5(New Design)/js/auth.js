<!-- js/auth.js -->
<script type="module">
import { auth, db } from "./firebase.js";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { ref, set } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

window.login = async () => {
  const email = emailInput.value;
  const pass  = passwordInput.value;
  await signInWithEmailAndPassword(auth, email, pass);
  location.href = "index.html";
};

window.register = async () => {
  const email = emailInput.value;
  const pass  = passwordInput.value;
  const res = await createUserWithEmailAndPassword(auth, email, pass);

  await set(ref(db, "users/" + res.user.uid), {
    uid: res.user.uid,
    name: email.split("@")[0],
    avatar: ""
  });

  location.href = "index.html";
};
</script>