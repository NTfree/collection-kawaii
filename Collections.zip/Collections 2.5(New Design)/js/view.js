// ================= ELEMENT =================
const viewer = document.getElementById("viewer");
const topbar = document.getElementById("topbar");
const bottombar = document.getElementById("bottombar");
const pageIndicator = document.getElementById("pageIndicator");
const btnHeart = document.getElementById("btnHeart");

let barVisible = true;
let currentSlideIndex = 0;
let favorites = JSON.parse(localStorage.getItem("favorites_collection") || "[]");

// ================= LOAD FROM SESSION =================
const images = JSON.parse(sessionStorage.getItem("allImages") || "[]");
const startIndex = Number(sessionStorage.getItem("startIndex") || 0);

if (!images.length) {
  location.href = "index.html";
}

// 1. TẠO KHUNG ẢO (KHÔNG LOAD ẢNH) ĐỂ DOM KHÔNG BỊ NẶNG
images.forEach((_, index) => {
  const slide = document.createElement("div");
  slide.className = "slide";
  slide.id = `slide-${index}`;
  viewer.appendChild(slide);
});

// 2. NHẢY THẲNG TỚI ẢNH ĐƯỢC CHỌN (KHÔNG CUỘN TỪ TỪ NỮA)
setTimeout(() => {
  viewer.scrollLeft = startIndex * viewer.clientWidth;
  currentSlideIndex = startIndex;
  updateUI(startIndex);
  loadNearbySlides(startIndex); // Chỉ load 3 tấm gần nhất
}, 10);

// ================= HÀM CHỈ TẢI ẢNH GẦN MÌNH NHẤT =================
function loadSlideContent(index) {
  if (index < 0 || index >= images.length) return;
  const slide = document.getElementById(`slide-${index}`);
  
  // Nếu đã load rồi thì bỏ qua
  if (slide.hasChildNodes()) return; 

  const item = images[index];

  if (item.type === "video") {
    const video = document.createElement("video");
    video.src = item.url;
    video.controls = true;
    video.playsInline = true;
    video.setAttribute("webkit-playsinline", "");
    video.preload = "metadata";

    const timeBox = document.createElement("div");
    timeBox.className = "time-display";
    timeBox.innerText = "00:00 / 00:00";

    video.addEventListener("loadedmetadata", () => {
      timeBox.innerText = "00:00 / " + formatTime(video.duration);
    });

    video.addEventListener("timeupdate", () => {
      timeBox.innerText = formatTime(video.currentTime) + " / " + formatTime(video.duration);
    });

    video.addEventListener("click", toggleBars);

    slide.appendChild(video);
    slide.appendChild(timeBox);
  } else {
    const img = document.createElement("img");
    // Lấy link gốc full HD
    img.src = item.url;
    img.draggable = false;
    
    enableZoom(img);
    slide.appendChild(img);
  }
}

// Load tấm hiện tại, tấm bên trái và tấm bên phải
function loadNearbySlides(index) {
  loadSlideContent(index);
  loadSlideContent(index - 1);
  loadSlideContent(index + 1);
}

// Cập nhật khi vuốt qua ảnh khác
viewer.addEventListener("scroll", () => {
  const index = Math.round(viewer.scrollLeft / viewer.clientWidth);
  if (index !== currentSlideIndex) {
    currentSlideIndex = index;
    updateUI(index);
    loadNearbySlides(index); // Vuốt tới đâu tải tới đó
  }
});

// ================= GIAO DIỆN & THANH CÔNG CỤ =================
function toggleBars() {
  barVisible = !barVisible;
  topbar.classList.toggle("hide", !barVisible);
  bottombar.classList.toggle("hide", !barVisible);
  
  document.querySelectorAll('.time-display').forEach(el => {
    el.classList.toggle("hide", !barVisible);
  });
}

function updateUI(index) {
  pageIndicator.innerText = `${index + 1} / ${images.length}`;
  const currentUrl = images[index].url;
  if (favorites.includes(currentUrl)) {
    btnHeart.innerHTML = `<i class="fa-solid fa-heart"></i>`;
  } else {
    btnHeart.innerHTML = `<i class="fa-regular fa-heart"></i>`;
  }
}

// ================= TÍNH NĂNG BOTTOM BAR =================
function toggleHeart() {
  const currentUrl = images[currentSlideIndex].url;
  const favIndex = favorites.indexOf(currentUrl);
  
  if (favIndex > -1) {
    favorites.splice(favIndex, 1);
    btnHeart.innerHTML = `<i class="fa-regular fa-heart"></i>`;
  } else {
    favorites.push(currentUrl);
    btnHeart.innerHTML = `<i class="fa-solid fa-heart" style="animation: pop 0.3s ease;"></i>`;
  }
  localStorage.setItem("favorites_collection", JSON.stringify(favorites));
}

function downloadCurrent() {
  const currentItem = images[currentSlideIndex];
  const a = document.createElement("a");
  a.href = currentItem.url;
  a.download = `Media_${Date.now()}`;
  a.target = "_blank"; 
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function shareCurrent() {
  const currentUrl = images[currentSlideIndex].url;
  if (navigator.share) {
    navigator.share({ title: 'Chia sẻ bộ sưu tập', text: 'Xem ảnh này nè!', url: currentUrl }).catch(console.error);
  } else {
    navigator.clipboard.writeText(currentUrl).then(() => alert("Đã chép liên kết!"));
  }
}

// ================= HÀM ZOOM ẢNH =================
function enableZoom(img) {
  let scale = 1;
  let lastTap = 0;
  
  img.addEventListener("touchend", (e) => {
    const currentTime = new Date().getTime();
    const tapLength = currentTime - lastTap;
    
    if (tapLength < 300 && tapLength > 0) {
      scale = scale > 1 ? 1 : 2.5; 
      img.style.transform = `scale(${scale})`;
      e.preventDefault();
    } else if (scale === 1 && e.touches.length === 0) {
      toggleBars();
    }
    lastTap = currentTime;
  });

  let startDist = 0;
  img.addEventListener("touchstart", (e) => {
    if (e.touches.length === 2) {
      startDist = Math.hypot(e.touches[0].pageX - e.touches[1].pageX, e.touches[0].pageY - e.touches[1].pageY);
    }
  });

  img.addEventListener("touchmove", (e) => {
    if (e.touches.length === 2) {
      e.preventDefault(); 
      const dist = Math.hypot(e.touches[0].pageX - e.touches[1].pageX, e.touches[0].pageY - e.touches[1].pageY);
      scale = Math.min(Math.max(1, dist / startDist), 4); 
      img.style.transform = `scale(${scale})`;
    }
  });

  img.addEventListener("touchend", (e) => {
    if (e.touches.length < 2 && scale < 1) {
      scale = 1;
      img.style.transform = `scale(1)`;
    }
  });
}

function formatTime(seconds){
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}`;
}
