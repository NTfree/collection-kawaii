<!-- js/firebase.js -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-storage.js";

export const firebaseConfig = {
  apiKey: "AIzaSyBc18kFu_5W7n2-q5pc5HgxKGsMU-1kLd0",
  authDomain: "collection712.firebaseapp.com",
  databaseURL: "https://collection712-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "collection712",
  storageBucket: "collection712.firebasestorage.app",
  messagingSenderId: "80032263959",
  appId: "1:80032263959:web:32b04947428ca5ea541152",
  measurementId: "G-202HX6J50E"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db   = getDatabase(app);
export const storage = getStorage(app);
</script>