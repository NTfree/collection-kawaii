/**************** FIREBASE INIT ****************/
const firebaseConfig = {
  apiKey: "AIzaSyBc18kFu_5W7n2-q5pc5HgxKGsMU-1kLd0",
  authDomain: "collection712.firebaseapp.com",
  databaseURL: "https://collection712-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "collection712"
};

let totalImagesCount = 0;
let maxImages = 10; 
let selectedCollectionId = null;
const VIDEO_COST_PER_MIN = 20;
let premiumPlan = "free";

const params = new URLSearchParams(window.location.search);
const editCollectionId = params.get("id");

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const db   = firebase.database();

/**************** CLOUDINARY CONFIG ****************/
const CLOUD_NAME    = "ddrxfpike";
const UPLOAD_PRESET = "collection712";

/**************** ELEMENTS ****************/
const nameInput  = document.getElementById("collectionName");
const descInput  = document.getElementById("collectionDesc"); // TÍNH NĂNG MỚI
const listEl     = document.getElementById("list");
const fileInput  = document.getElementById("fileInput");

// ELEMENTS PROGRESS BAR MỚI
const popup        = document.getElementById("uploadPopup");
const progressBar  = document.getElementById("progressBar");
const uploadPercent= document.getElementById("uploadPercent");
const uploadCount  = document.getElementById("uploadCount");

/**************** STATE ****************/
let uid = null;
let collectionId = null;
let imgIndex = 0;
let videoIndex = 0;

/**************** AUTH CHECK ****************/
auth.onAuthStateChanged(async user => {
  if (!user) {
    alert("Bạn chưa đăng nhập");
    history.back();
    return;
  }
  uid = user.uid;

  await loadUserPlan();
  await countUserImages();

  if (editCollectionId) {
    collectionId = editCollectionId;
    loadExistingCollection();
  } else {
    createEmptyCollection();
  }
});

/**************** CREATE COLLECTION IMMEDIATELY ****************/
function createEmptyCollection() {
  const time = Date.now();
  collectionId = `${uid}_${time}`;

  db.ref("collections/" + collectionId).set({
    uid,
    time,
    name: "Bộ sưu tập mới",
    desc: "", // THÊM TRƯỜNG DESC
    imgs: {},
    videos: {}
  });
}

/**************** LƯU TÊN & MÔ TẢ REALTIME ****************/
nameInput.addEventListener("input", () => {
  if (!collectionId) return;
  db.ref(`collections/${collectionId}/name`).set(nameInput.value.trim() || "Bộ sưu tập mới");
});

descInput.addEventListener("input", () => {
  if (!collectionId) return;
  db.ref(`collections/${collectionId}/desc`).set(descInput.value.trim());
});

/**************** PICK IMAGES ****************/
function pickImages() {
  if(totalImagesCount >= maxImages){
    document.getElementById("limitPopup").classList.add("show");
    return;
  }
  fileInput.click();
}

fileInput.addEventListener("change", async () => {
  const files = Array.from(fileInput.files);
  if (!files.length) return;

  // Reset Progress Bar UI
  popup.classList.add("show");
  progressBar.style.width = "0%";
  uploadPercent.innerText = "0%";
  uploadCount.innerText = `0 / ${files.length} file`;

  let uploaded = 0;

  for (const file of files) {
    const isVideo = file.type.startsWith("video");

    if (isVideo && !["advanced","pro","unlimited"].includes(premiumPlan)) {
      alert("Gói Advanced trở lên mới đăng video 🥹");
      continue;
    }

    let storageCost = 1;

    if (isVideo) {
      const duration = await getVideoDuration(file);
      const minutes = Math.ceil(duration / 60);
      storageCost = minutes * VIDEO_COST_PER_MIN;

      if (totalImagesCount + storageCost > maxImages) {
        document.getElementById("limitPopup").classList.add("show");
        continue;
      }
    } else {
      if(totalImagesCount >= maxImages){
        document.getElementById("limitPopup").classList.add("show");
        continue;
      }
    }

    const url = await uploadToCloudinary(file, isVideo);

    if (url) {
      if (isVideo) {
        const key = saveVideo(url, storageCost);
        addMediaToUI(url, key, true); // Gọi hàm UI chung
      } else {
        const key = saveImage(url);
        addMediaToUI(url, key, false); // Gọi hàm UI chung
      }
      totalImagesCount += storageCost;
    }

    uploaded++;
    
    // UPDATE PROGRESS BAR MƯỢT MÀ
    let percent = Math.round((uploaded / files.length) * 100);
    progressBar.style.width = percent + "%";
    uploadPercent.innerText = percent + "%";
    uploadCount.innerText = `${uploaded} / ${files.length} file`;
  }

  // Chờ 0.5s rồi tắt popup cho mượt
  setTimeout(() => {
    popup.classList.remove("show");
  }, 600);
  
  fileInput.value = "";
});

/**************** UPLOAD TO CLOUDINARY ****************/
async function uploadToCloudinary(file, isVideo=false) {
  const form = new FormData();
  form.append("file", file);
  form.append("upload_preset", UPLOAD_PRESET);
  const type = isVideo ? "video" : "image";

  try {
    const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${type}/upload`, { method: "POST", body: form });
    const data = await res.json();
    return data.secure_url;
  } catch (e) {
    console.error("Upload lỗi:", e);
    return null;
  }
}

/**************** LƯU VÀ LẤY KEY TỪ DATABASE ****************/
function saveImage(url) {
  const key = imgIndex;
  db.ref(`collections/${collectionId}/imgs/${key}`).set(url);
  imgIndex++;
  return key;
}

function saveVideo(url, cost) {
  const key = videoIndex;
  db.ref(`collections/${collectionId}/videos/${key}`).set({ url: url, cost: cost });
  videoIndex++;
  return key;
}

/**************** UI: HÀM VẼ GIAO DIỆN MEDIA (CÓ NÚT XÓA) ****************/
function addMediaToUI(url, key, isVideo) {
  const item = document.createElement("div");
  item.className = "media-item";
  
  // NÚT XÓA (TÍNH NĂNG MỚI)
  const delBtn = document.createElement("div");
  delBtn.className = "delete-badge";
  delBtn.innerHTML = `<i class="fa-solid fa-xmark"></i>`;
  delBtn.onclick = (e) => {
    e.stopPropagation(); // Tránh click vào ảnh
    if(confirm("Bạn muốn xóa tệp này khỏi bộ sưu tập?")) {
      const path = isVideo ? `videos/${key}` : `imgs/${key}`;
      db.ref(`collections/${collectionId}/${path}`).remove().then(() => {
        item.remove(); // Xóa khỏi màn hình mượt mà
      });
    }
  };

  let mediaEl;
  if (isVideo) {
    mediaEl = document.createElement("video");
    mediaEl.controls = true;
  } else {
    mediaEl = document.createElement("img");
    mediaEl.draggable = false;
    
    mediaEl.addEventListener("click", () => {
      const allItems = [];
      document.querySelectorAll(".media-item").forEach(el => {
        const i = el.querySelector("img");
        const v = el.querySelector("video");
        if (i) allItems.push({ type: "image", url: i.src });
        if (v) allItems.push({ type: "video", url: v.src });
      });
      const index = allItems.findIndex(m => m.url === url);
      sessionStorage.setItem("allImages", JSON.stringify(allItems));
      sessionStorage.setItem("startIndex", index);
      location.href = "view.html";
    });
  }
  
  mediaEl.src = url;
  item.appendChild(mediaEl);
  item.appendChild(delBtn); // Thêm nút xóa vào DOM
  listEl.appendChild(item);
}

function loadExistingCollection() {
  db.ref("collections/" + collectionId).once("value").then(snap => {
    const data = snap.val();
    if (!data) return;

    nameInput.value = data.name || "";
    descInput.value = data.desc || ""; // Load mô tả

    if (data.videos) {
      const vKeys = Object.keys(data.videos);
      videoIndex = Math.max(...vKeys.map(Number)) + 1 || 0; // Set index an toàn
      vKeys.forEach(k => addMediaToUI(data.videos[k].url, k, true));
    }

    if (data.imgs) {
      const iKeys = Object.keys(data.imgs);
      imgIndex = Math.max(...iKeys.map(Number)) + 1 || 0;
      iKeys.forEach(k => addMediaToUI(data.imgs[k], k, false));
    }
  });
}

function loadUserPlan(){
  return db.ref("users/" + uid + "/premiumPlan").once("value").then(snap=>{
      premiumPlan = snap.val() || "free";
      const limits = { free: 1000, basic: 10000, advanced: 50000, pro: 100000, unlimited: Infinity };
      maxImages = limits[premiumPlan] ?? 1000;
  });
}

function countUserImages(){
  return db.ref("collections").orderByChild("uid").equalTo(uid).once("value").then(snap=>{
      let count = 0;
      snap.forEach(child=>{
        const col = child.val();
        if(col.imgs) count += Object.keys(col.imgs).length;
        if(col.videos) Object.values(col.videos).forEach(v => count += v.cost || VIDEO_COST_PER_MIN);
      });
      totalImagesCount = count;
  });
}

function getVideoDuration(file){
  return new Promise(resolve=>{
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => resolve(video.duration);
    video.src = URL.createObjectURL(file);
  });
}

function closeLimit(){ document.getElementById("limitPopup").classList.remove("show"); }
function goPro(){ location.href = "proads.html"; }
