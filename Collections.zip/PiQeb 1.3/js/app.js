// js/app.js
const firebaseConfig = {
    apiKey: "AIzaSyDdGsHT3Wmi-InkaWm0SNYQtLkpEQUHl1g",
    authDomain: "piqebs.firebaseapp.com",
    databaseURL: "https://piqebs-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "piqebs",
    storageBucket: "piqebs.firebasestorage.app",
    messagingSenderId: "363663563522",
    appId: "1:363663563522:web:8b195b77b76461c57d001b",
    measurementId: "G-KTLC34PF5X"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();
const IMGBB_API_KEY = "16cdb57fa554b5f30b7647cbf752cc34";

let currentUser = null;
let localHistory = [];
let localBookmarks = [];

const iframe = document.getElementById('webview');
const urlInput = document.getElementById('url-input');
const homeScreen = document.getElementById('home-screen');
const overlay = document.getElementById('overlay');
const settingsSheet = document.getElementById('settings-sheet');
const moreMenu = document.getElementById('more-menu');
const bottomBar = document.getElementById('bottom-bar');
const btnBack = document.getElementById('btn-back');
const btnForward = document.getElementById('btn-forward');
const btnReload = document.getElementById('btn-reload');

// --- HỆ THỐNG QUẢN LÝ TAB BẰNG LOCALSTORAGE ---
let tabs = JSON.parse(localStorage.getItem('safari_tabs')) || [{ id: Date.now(), history: [], currentIndex: -1, url: '' }];
let activeTabId = localStorage.getItem('safari_active_tab') || tabs[0].id;

function getActiveTab() { return tabs.find(t => t.id == activeTabId) || tabs[0]; }
function saveTabs() { localStorage.setItem('safari_tabs', JSON.stringify(tabs)); localStorage.setItem('safari_active_tab', activeTabId); }

function updateNavUI() {
    const tab = getActiveTab();
    
    if (tab.currentIndex >= 0) { btnBack.classList.remove('hidden'); btnReload.classList.remove('hidden'); } 
    else { btnBack.classList.add('hidden'); btnReload.classList.add('hidden'); }

    if (tab.currentIndex < tab.history.length - 1) btnForward.classList.remove('hidden');
    else btnForward.classList.add('hidden');

    if (tab.currentIndex === -1 || !tab.url) {
        iframe.classList.add('hidden'); 
        iframe.src = ''; 
        homeScreen.classList.remove('hidden'); 
        urlInput.value = ""; 
        bottomBar.classList.remove('compact'); 
    } else {
        homeScreen.classList.add('hidden'); 
        iframe.classList.remove('hidden'); 
        iframe.src = tab.url; 
        urlInput.value = tab.url;
    }
}

function switchTab(id) {
    const isSameTab = (activeTabId == id);
    activeTabId = id; 
    saveTabs(); 
    document.getElementById('tab-manager').classList.add('hidden'); 
    if (!isSameTab) { updateNavUI(); }
}

function loadUrl(input, isHistoryAction = false) {
    let rawInput = input.trim();
    if (!rawInput) return;

    let isDirectUrl = (rawInput.includes('.') && !rawInput.includes(' ')) || rawInput.startsWith('http');
    let finalUrl = isDirectUrl ? (rawInput.startsWith('http') ? rawInput : 'https://' + rawInput) : `https://www.google.com/search?q=${encodeURIComponent(rawInput)}&igu=1`;

    const tab = getActiveTab();
    if (!isHistoryAction) { tab.history = tab.history.slice(0, tab.currentIndex + 1); tab.history.push(finalUrl); tab.currentIndex++; }
    tab.url = finalUrl; saveTabs(); updateNavUI();
    
    if (currentUser) {
        db.ref(`users/${currentUser.uid}/history`).push({ url: finalUrl, title: rawInput, timestamp: firebase.database.ServerValue.TIMESTAMP });
    }
}

btnBack.addEventListener('click', () => {
    const tab = getActiveTab();
    if (tab.currentIndex > 0) { tab.currentIndex--; loadUrl(tab.history[tab.currentIndex], true); } 
    else if (tab.currentIndex === 0) { tab.currentIndex = -1; tab.url = ''; saveTabs(); updateNavUI(); }
});
btnForward.addEventListener('click', () => {
    const tab = getActiveTab();
    if (tab.currentIndex < tab.history.length - 1) { tab.currentIndex++; loadUrl(tab.history[tab.currentIndex], true); }
});
btnReload.addEventListener('click', () => { if(!iframe.classList.contains('hidden')) iframe.src = iframe.src; });

// --- TỰ ĐỘNG THU GỌN / NỞ RA THANH CÔNG CỤ ---
window.addEventListener('blur', () => {
    if (document.activeElement === iframe && getActiveTab().url !== '') {
        setTimeout(() => bottomBar.classList.add('compact'), 100);
    }
});

bottomBar.addEventListener('click', function(e) {
    if (this.classList.contains('compact')) { this.classList.remove('compact'); e.stopPropagation(); }
});

let scrollStartY = 0;
document.addEventListener('touchstart', e => { scrollStartY = e.touches[0].clientY; }, {passive: true});
document.addEventListener('touchmove', e => {
    if(homeScreen.classList.contains('hidden')) return; 
    let currentY = e.touches[0].clientY;
    if (scrollStartY - currentY > 20) bottomBar.classList.add('compact'); 
    else if (currentY - scrollStartY > 20) bottomBar.classList.remove('compact'); 
}, {passive: true});


// --- QUẢN LÝ TAB (SỬA LỖI TỰ ĐÓNG KHI TẠO MỚI) ---
const tabManager = document.getElementById('tab-manager');
let touchStartY = 0;

bottomBar.addEventListener('touchstart', e => { touchStartY = e.touches[0].clientY; }, {passive: true});
bottomBar.addEventListener('touchend', e => {
    let touchEndY = e.changedTouches[0].clientY;
    if (touchStartY - touchEndY > 40) { bottomBar.classList.remove('compact'); renderTabManager(); tabManager.classList.remove('hidden'); }
});

document.getElementById('menu-tabs-open').addEventListener('click', () => { closeAll(); renderTabManager(); tabManager.classList.remove('hidden'); });
document.getElementById('btn-close-tabs').addEventListener('click', () => tabManager.classList.add('hidden'));

// ĐÃ SỬA: KHÔNG GỌI switchTab NỮA ĐỂ TRÁNH BỊ ẨN MÀN HÌNH QUẢN LÝ
document.getElementById('btn-new-tab').addEventListener('click', () => {
    const newTab = { id: Date.now() + Math.random(), history: [], currentIndex: -1, url: '' };
    tabs.push(newTab); 
    activeTabId = newTab.id; // Thiết lập tab này đang active
    saveTabs(); 
    updateNavUI(); // Load Iframe ngầm bên dưới
    renderTabManager(); // Load lại giao diện các thẻ
    
    // Tự động cuộn xuống cuối để thấy tab vừa tạo
    const tabList = document.getElementById('tab-list'); 
    tabList.scrollTop = tabList.scrollHeight;
});

function renderTabManager() {
    const tabList = document.getElementById('tab-list'); 
    tabList.innerHTML = '';
    tabs.forEach(tab => {
        const card = document.createElement('div'); 
        card.className = `tab-card ${tab.id == activeTabId ? 'active' : ''}`;
        
        // Đã sửa lại nút X dùng mã HTML &times; (×) cực nét, ko bị lỗi font
        card.innerHTML = `
            <div class="tab-click-area" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; border-radius: 15px; cursor: pointer;"></div>
            <button class="btn-close-tab" style="position: relative; z-index: 10;" data-id="${tab.id}">&times;</button>
            <div class="tab-card-title" style="position: relative; z-index: 2;">${tab.url ? 'Trang Web' : 'Trang Chủ'}</div>
            <div class="tab-card-url" style="position: relative; z-index: 2;">${tab.url || 'Khám phá Internet...'}</div>
        `;
        
        card.querySelector('.tab-click-area').addEventListener('click', (e) => {
            e.stopPropagation();
            switchTab(tab.id);
        });

        card.querySelector('.btn-close-tab').addEventListener('click', (e) => {
            e.stopPropagation();
            card.classList.add('removing');
            setTimeout(() => {
                tabs = tabs.filter(t => t.id != tab.id);
                if(tabs.length === 0) tabs.push({ id: Date.now() + Math.random(), history: [], currentIndex: -1, url: '' });
                if(activeTabId == tab.id) activeTabId = tabs[tabs.length-1].id;
                saveTabs(); 
                if(activeTabId == tab.id) updateNavUI(); 
                renderTabManager();
            }, 250);
        });

        tabList.appendChild(card);
    });
}

// --- GỢI Ý TÌM KIẾM & XÓA LỊCH SỬ ---
const searchOverlay = document.getElementById('search-overlay');
const overlayUrlInput = document.getElementById('overlay-url-input');
const btnClearInput = document.getElementById('btn-clear-input');

window.clearSearchHistory = async function(e) {
    e.stopPropagation();
    if(confirm("Bạn có chắc chắn muốn xóa toàn bộ lịch sử tìm kiếm?")) {
        if(currentUser) { await db.ref(`users/${currentUser.uid}/history`).remove(); }
        localHistory = []; renderSuggestions(""); 
    }
};

function renderSuggestions(query = "") {
    const list = document.getElementById('search-suggestion-list'); list.innerHTML = '';
    
    if(!query) {
        const recents = localHistory.slice(0, 8); 
        if(recents.length > 0) {
            list.innerHTML += `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 20px; border-bottom: 1px solid rgba(0,0,0,0.05); background: #f8f9fa;">
                    <span style="font-size: 0.85rem; font-weight: 600; color: #747d8c; text-transform: uppercase;">Lịch sử tìm kiếm</span>
                    <button onclick="window.clearSearchHistory(event)" style="background: transparent; border: none; color: #ff4757; font-size: 0.85rem; font-weight: 600; cursor: pointer;">Xóa tất cả</button>
                </div>
            `;
        }
        recents.forEach(item => {
            list.innerHTML += `<li onclick="window.executeSuggestion('${item.url}')"><i class="fas fa-history"></i> <div class="suggest-text-wrapper"><span class="suggest-title">${item.title || item.url}</span><span class="suggest-url">${item.url}</span></div></li>`;
        });
        if(recents.length === 0) list.innerHTML = '<p style="text-align:center; padding: 20px; color:#747d8c;">Nhập từ khóa hoặc URL để bắt đầu duyệt web...</p>';
        return;
    }

    const q = query.toLowerCase(); let matches = [];
    localBookmarks.forEach(item => {
        if((item.title && item.title.toLowerCase().includes(q)) || item.url.toLowerCase().includes(q)) matches.push({...item, type: 'bookmark'});
    });
    localHistory.forEach(item => {
        if((item.title && item.title.toLowerCase().includes(q)) || item.url.toLowerCase().includes(q)) {
            if(!matches.find(m => m.url === item.url)) matches.push({...item, type: 'history'});
        }
    });

    matches = matches.slice(0, 10);
    matches.forEach(item => {
        const icon = item.type === 'bookmark' ? '<i class="fas fa-star" style="color:#f1c40f"></i>' : '<i class="fas fa-history"></i>';
        list.innerHTML += `<li onclick="window.executeSuggestion('${item.url}')">${icon} <div class="suggest-text-wrapper"><span class="suggest-title">${item.title || item.url}</span><span class="suggest-url">${item.url}</span></div></li>`;
    });

    list.innerHTML = `<li onclick="window.executeSuggestion('${query}')"><i class="fas fa-search" style="color:#0984e3"></i> <div class="suggest-text-wrapper"><span class="suggest-title" style="color:#0984e3">Tìm kiếm Google cho "${query}"</span></div></li>` + list.innerHTML;
}

window.executeSuggestion = function(query) { searchOverlay.classList.add('hidden'); loadUrl(query); }

document.querySelector('.search-input-wrapper').addEventListener('click', (e) => {
    if(bottomBar.classList.contains('compact')) return;
    searchOverlay.classList.remove('hidden'); overlayUrlInput.value = urlInput.value; toggleClearButton();
    renderSuggestions(overlayUrlInput.value); 
    setTimeout(() => { overlayUrlInput.focus(); overlayUrlInput.select(); }, 100);
});

document.getElementById('btn-close-search').addEventListener('click', () => searchOverlay.classList.add('hidden'));

function toggleClearButton() { if (overlayUrlInput.value.length > 0) btnClearInput.classList.remove('hidden'); else btnClearInput.classList.add('hidden'); }
overlayUrlInput.addEventListener('input', (e) => { toggleClearButton(); renderSuggestions(e.target.value); });
btnClearInput.addEventListener('click', () => { overlayUrlInput.value = ''; toggleClearButton(); renderSuggestions(""); overlayUrlInput.focus(); });
document.getElementById('btn-submit-search').addEventListener('click', () => window.executeSuggestion(overlayUrlInput.value.trim()));
overlayUrlInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') window.executeSuggestion(overlayUrlInput.value.trim()); });

// --- DẤU TRANG & LỊCH SỬ VIEWER ---
const dataViewerModal = document.getElementById('data-viewer-modal');
const dataViewerTitle = document.getElementById('data-viewer-title');
const dataList = document.getElementById('data-list');
const btnClearHistory = document.getElementById('btn-clear-history');

document.getElementById('menu-save').addEventListener('click', () => {
    const tab = getActiveTab();
    if (!currentUser) return alert("Cần đăng nhập để lưu Dấu trang!");
    if (!tab.url) return alert("Trang chủ không thể lưu!");
    db.ref(`users/${currentUser.uid}/saved`).push({ url: tab.url, title: "Dấu trang đã lưu", timestamp: firebase.database.ServerValue.TIMESTAMP });
    alert("Đã lưu Dấu trang thành công!"); closeAll();
});

document.getElementById('menu-view-bookmarks').addEventListener('click', () => {
    if (!currentUser) return alert("Cần đăng nhập!");
    closeAll(); dataViewerTitle.innerText = "Dấu trang của bạn"; btnClearHistory.classList.add('hidden'); 
    dataViewerModal.classList.remove('hidden'); overlay.classList.remove('hidden');
    db.ref(`users/${currentUser.uid}/saved`).once('value', snap => renderDataList(snap.val(), false, 'saved'));
});

document.getElementById('menu-history').addEventListener('click', () => {
    if (!currentUser) return alert("Cần đăng nhập!");
    closeAll(); dataViewerTitle.innerText = "Lịch sử duyệt web"; btnClearHistory.classList.remove('hidden'); 
    dataViewerModal.classList.remove('hidden'); overlay.classList.remove('hidden');
    db.ref(`users/${currentUser.uid}/history`).limitToLast(50).once('value', snap => renderDataList(snap.val(), true, 'history'));
});

btnClearHistory.addEventListener('click', async () => {
    if (confirm("Xóa toàn bộ lịch sử?")) {
        await db.ref(`users/${currentUser.uid}/history`).remove();
        renderDataList(null); alert("Đã xóa!");
    }
});
document.getElementById('btn-close-data-viewer').addEventListener('click', closeAll);

function renderDataList(dataObj, reverse = false, dataType = 'history') {
    dataList.innerHTML = '';
    if (!dataObj) return dataList.innerHTML = '<p style="text-align:center; padding: 20px; color: #555;">Dữ liệu trống.</p>';
    
    let keys = Object.keys(dataObj);
    if(reverse) keys = keys.reverse();

    keys.forEach(key => {
        const item = dataObj[key];
        const li = document.createElement('li');
        li.innerHTML = `<div class="data-info"><span class="data-title">${item.title || item.url}</span><span class="data-url">${item.url}</span></div><button class="btn-delete-data" title="Xóa"><i class="fas fa-trash-alt"></i></button>`;
        li.querySelector('.data-info').onclick = () => { loadUrl(item.url); closeAll(); };
        li.querySelector('.btn-delete-data').onclick = async (e) => {
            e.stopPropagation();
            li.style.transform = 'scale(0.9)'; li.style.opacity = '0'; li.style.transition = '0.3s';
            setTimeout(async () => {
                await db.ref(`users/${currentUser.uid}/${dataType}/${key}`).remove(); li.remove();
                if(dataList.children.length === 0) dataList.innerHTML = '<p style="text-align:center; padding: 20px; color: #555;">Dữ liệu trống.</p>';
            }, 300);
        };
        dataList.appendChild(li);
    });
}

// --- QUẢN LÝ SHORTCUTS MÀN HÌNH CHÍNH ---
const shortcutModal = document.getElementById('shortcut-modal');

document.getElementById('btn-add-shortcut').addEventListener('click', () => {
    if (!currentUser) return alert("Bạn cần đăng nhập để lưu lối tắt!");
    shortcutModal.classList.remove('hidden'); overlay.classList.remove('hidden');
});
document.getElementById('btn-cancel-shortcut').addEventListener('click', () => { shortcutModal.classList.add('hidden'); overlay.classList.add('hidden'); });

document.getElementById('btn-save-shortcut').addEventListener('click', async () => {
    const name = document.getElementById('new-shortcut-name').value;
    const url = document.getElementById('new-shortcut-url').value;
    if (name && url) {
        await db.ref(`users/${currentUser.uid}/shortcuts`).push({ name, url });
        shortcutModal.classList.add('hidden'); overlay.classList.add('hidden');
        document.getElementById('new-shortcut-name').value = ''; document.getElementById('new-shortcut-url').value = '';
    }
});

function renderShortcuts(shortcutsData) {
    const quickLinks = document.getElementById('quick-links');
    const addBtn = document.getElementById('btn-add-shortcut');
    quickLinks.innerHTML = ''; quickLinks.appendChild(addBtn);

    if (shortcutsData) {
        Object.keys(shortcutsData).forEach(key => {
            const item = shortcutsData[key];
            const btn = document.createElement('div');
            btn.className = 'glass-btn shortcut';
            btn.innerHTML = `${item.name.charAt(0).toUpperCase()} <button class="btn-delete-shortcut" data-key="${key}">×</button>`;
            btn.onclick = (e) => { if(e.target.className !== 'btn-delete-shortcut') loadUrl(item.url); };
            btn.querySelector('.btn-delete-shortcut').onclick = () => { db.ref(`users/${currentUser.uid}/shortcuts/${key}`).remove(); };
            quickLinks.insertBefore(btn, addBtn);
        });
    }
}

// --- LOGIC AUTH & CÀI ĐẶT ---
document.getElementById('tab-btn-login').addEventListener('click', () => switchTabAuth('login'));
document.getElementById('tab-btn-register').addEventListener('click', () => switchTabAuth('register'));

function switchTabAuth(tab) {
    const authMsg = document.getElementById('auth-msg'); authMsg.innerText = "";
    if (tab === 'login') {
        document.getElementById('tab-btn-login').classList.add('active'); document.getElementById('tab-btn-register').classList.remove('active');
        document.getElementById('tab-login').classList.remove('hidden'); document.getElementById('tab-register').classList.add('hidden');
    } else {
        document.getElementById('tab-btn-register').classList.add('active'); document.getElementById('tab-btn-login').classList.remove('active');
        document.getElementById('tab-register').classList.remove('hidden'); document.getElementById('tab-login').classList.add('hidden');
    }
}

async function uploadToImgBB(file) {
    const fd = new FormData(); fd.append('image', file);
    const res = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, { method: 'POST', body: fd });
    const json = await res.json();
    return json.data.url;
}

document.getElementById('btn-do-login').addEventListener('click', async () => {
    const email = document.getElementById('login-email').value; const pass = document.getElementById('login-pass').value;
    const authMsg = document.getElementById('auth-msg');
    if(!email || !pass) return authMsg.innerText = "Nhập đủ thông tin!";
    authMsg.innerText = "Đang kiểm tra..."; authMsg.style.color = "blue";
    try { await auth.signInWithEmailAndPassword(email, pass); closeAll(); } 
    catch(err) { authMsg.style.color = "red"; authMsg.innerText = "Sai thông tin hoặc lỗi mạng!"; }
});

document.getElementById('btn-do-register').addEventListener('click', async () => {
    const file = document.getElementById('reg-avatar').files[0]; const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value; const pass = document.getElementById('reg-pass').value;
    const authMsg = document.getElementById('auth-msg');
    if(!file || !name || !email || !pass) return authMsg.innerText = "Điền đủ thông tin và chọn Avatar!";
    authMsg.innerText = "Đang xử lý..."; authMsg.style.color = "blue";
    try {
        const avatarUrl = await uploadToImgBB(file);
        const cred = await auth.createUserWithEmailAndPassword(email, pass);
        await db.ref('users/' + cred.user.uid).set({ uid: cred.user.uid, name: name, avatar: avatarUrl, history: "", saved: "" });
        closeAll();
    } catch (err) { authMsg.style.color = "red"; authMsg.innerText = err.message; }
});

auth.onAuthStateChanged(user => {
    if (user) {
        currentUser = user;
        document.getElementById('auth-section').classList.add('hidden');
        document.getElementById('profile-section').classList.remove('hidden');
        
        db.ref(`users/${user.uid}/shortcuts`).on('value', snap => renderShortcuts(snap.val()));
        db.ref(`users/${user.uid}/history`).on('value', snap => { localHistory = snap.val() ? Object.values(snap.val()).reverse() : []; });
        db.ref(`users/${user.uid}/saved`).on('value', snap => { localBookmarks = snap.val() ? Object.values(snap.val()).reverse() : []; });

        db.ref('users/' + user.uid).on('value', snap => {
            const data = snap.val();
            if (data) {
                document.getElementById('btn-account').src = data.avatar;
                document.getElementById('profile-avatar').src = data.avatar;
                document.getElementById('profile-name').innerText = data.name;
                if (data.background) document.body.style.backgroundImage = data.background.startsWith('http') ? `url(${data.background})` : data.background;
                if (data.themeColor) document.documentElement.style.setProperty('--theme-color', data.themeColor);

                const homeTextEl = document.getElementById('home-display-text');
                if (data.homeText) {
                    homeTextEl.innerText = data.homeText.content || "Khám phá";
                    homeTextEl.style.color = data.homeText.color || "#0984e3";
                    homeTextEl.style.fontSize = (data.homeText.size || 40) + "px";
                    
                    document.getElementById('set-home-text').value = data.homeText.content || "";
                    document.getElementById('set-home-color').value = data.homeText.color || "#0984e3";
                    document.getElementById('set-home-size').value = data.homeText.size || 40;
                }
            }
        });
    } else {
        currentUser = null;
        localHistory = []; localBookmarks = [];
        document.getElementById('auth-section').classList.remove('hidden');
        document.getElementById('profile-section').classList.add('hidden');
        document.getElementById('btn-account').src = "https://via.placeholder.com/40";
        document.body.style.backgroundImage = "linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%)";
    }
});

// Cài đặt giao diện
document.querySelectorAll('.grad-box').forEach(box => {
    box.addEventListener('click', () => { window.selectedGrad = box.getAttribute('data-grad'); document.body.style.backgroundImage = window.selectedGrad; });
});

document.getElementById('btn-save-settings').addEventListener('click', async () => {
    const msg = document.getElementById('profile-msg'); msg.innerText = "Đang lưu...";
    const updates = { homeText: { content: document.getElementById('set-home-text').value, color: document.getElementById('set-home-color').value, size: document.getElementById('set-home-size').value } };
    if (window.selectedGrad) updates.background = window.selectedGrad;
    const bgFile = document.getElementById('file-bg').files[0];
    if (bgFile) updates.background = await uploadToImgBB(bgFile);
    await db.ref('users/' + currentUser.uid).update(updates);
    msg.innerText = "Đã lưu!"; setTimeout(closeAll, 1000);
});

// Tiện ích Đóng/Mở
document.getElementById('btn-menu').addEventListener('click', () => { moreMenu.classList.toggle('hidden'); overlay.classList.remove('hidden'); });
document.getElementById('btn-account').addEventListener('click', () => { settingsSheet.classList.remove('hidden'); overlay.classList.remove('hidden'); });
document.getElementById('btn-logout').addEventListener('click', () => { auth.signOut(); closeAll(); });
function closeAll() { 
    moreMenu.classList.add('hidden'); settingsSheet.classList.add('hidden'); 
    overlay.classList.add('hidden'); shortcutModal.classList.add('hidden'); 
    dataViewerModal.classList.add('hidden');
}
overlay.addEventListener('click', closeAll);
document.getElementById('btn-close-settings').addEventListener('click', closeAll);

updateNavUI();
